'use strict';

/**
 * ad-attachment controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::ad-attachment.ad-attachment');
