'use strict';

/**
 * ad-attachment router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::ad-attachment.ad-attachment');
