'use strict';

/**
 * ad-attachment service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::ad-attachment.ad-attachment');
