'use strict';

/**
 * m-product controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::m-product.m-product');
