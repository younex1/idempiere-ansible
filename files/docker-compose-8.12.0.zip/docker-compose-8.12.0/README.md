# ELK Docker Compose

This is a guide for setting up the ELK (Elasticsearch, Logstash, Kibana) stack using Docker Compose, specifically for version 8.12.0. The ELK stack is widely used for searching, analyzing, and visualizing log data in real-time.

---

## Introduction

This guide will walk you through the process of setting up the ELK stack using Docker Compose. The ELK stack is a powerful combination of tools for managing and analyzing log data, and Docker Compose simplifies the process by allowing you to manage all three components in containers.

---

## What You’ll Need

Before you begin, ensure that you have the following:

- A Linux system (like Ubuntu)
- `sudo` privileges on your system
- Docker installed
- Docker Compose installed

---

## Step 1: Preparing Your System

Before installing Docker and Docker Compose, you'll need to update your system's package list and install some dependencies.

### Update Package List

First, update your system's package list to ensure you have the latest software versions available:

```bash
sudo apt update
```

### Install Dependencies

Next, install essential dependencies that Docker requires:

```bash
sudo apt install apt-transport-https ca-certificates curl software-properties-common
```

### Install Docker

Docker is a platform that allows you to run applications in containers. Containers are lightweight and portable environments that include everything an application needs to run.

1. **Download the Docker installation script:**
   ```bash
   curl -fsSL https://get.docker.com -o get-docker.sh
   ```

2. **Check if Docker can be installed:**
   ```bash
   sudo sh ./get-docker.sh --dry-run
   ```

3. **Run the installation script to install Docker:**
   ```bash
   sudo sh ./get-docker.sh
   ```

### Add User to Docker Group

To avoid needing `sudo` every time you run Docker, add your user to the Docker group:

```bash
sudo usermod -aG docker $USER
```

### Install Docker Compose

Docker Compose is a tool that allows you to manage multi-container Docker applications. Install it with the following command:

```bash
sudo apt install docker-compose -y
```

### Enable Docker

Ensure that Docker starts automatically when your system boots up:

```bash
sudo systemctl enable docker
```

### Start Docker

Start the Docker service immediately:

```bash
sudo systemctl start docker
```

### Check Docker Status

Verify that Docker is running correctly:

```bash
sudo systemctl status docker
```

---

## Configurations

You only need to add your pipeline configuration to the Logstash pipeline configuration file. The rest of the configurations are already set up for you.

### Logstash Pipelines

Logstash pipelines define how data is processed and are configured in the following file:

```bash
./elk/logstash/pipeline/
```

---

## Setting Up ELK Docker Compose

With Docker and Docker Compose installed, you can now set up the ELK stack using Docker Compose.

### Extract the ELK Docker Compose Code

If your ELK Docker Compose code is in a zip file, extract it with the following command:

```bash
unzip elk-docker-compose-8.12.0.zip
```

### Change Directory to ELK

Navigate to the directory containing the ELK Docker Compose code:

```bash
cd elk-docker-compose-8.12.0
```

### Start Docker Containers

Build and start the Docker containers in the background using this command:

```bash
docker-compose up -d --build
```

### Restart Docker Containers

To restart the containers after making changes:

```bash
docker-compose restart
```

### Check Docker Containers

To check if the Docker containers are running, use the following command:

```bash
docker ps
```

### Access Kibana

Kibana is the web interface for exploring and visualizing your log data. Open your web browser and go to:

```bash
http://localhost:37828
```

### Access Elasticsearch

Elasticsearch stores your log data and allows you to search through it. Access it via your web browser:

```bash
https://localhost:37820
```

### Access Logstash

To enter the Logstash container and manage it directly:

```bash
docker exec -it logstash bash
```

### Access Kibana

To enter the Kibana container:

```bash
docker exec -it kibana bash
```

### Access Elasticsearch

To enter the Elasticsearch container:

```bash
docker exec -it elasticsearch bash
```

### Stop Docker Containers

When you're done, you can stop the Docker containers with:

```bash
docker-compose down
```

### Remove Docker Containers

To remove the containers completely:

```bash
docker-compose down --volumes
```

### Remove Docker Images

If you need to clean up Docker images:

```bash
docker rmi $(docker images -q)
```

### Remove Docker Volumes

To remove Docker volumes, which hold persistent data:

```bash
docker volume rm $(docker volume ls -q)
```

### Remove Docker Networks

Finally, to remove any Docker networks that were created:

```bash
docker network rm $(docker network ls -q)
```

---

## Conclusion

You have successfully set up the ELK stack using Docker Compose. You can now use Elasticsearch, Logstash, and Kibana to search, analyze, and visualize your log data in real-time.

---

## Developer
- [Muhammad Zubair Saleem](https://www.linkedin.com/in/mzubairsaleem/)