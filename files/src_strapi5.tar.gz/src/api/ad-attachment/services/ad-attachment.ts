/**
 * ad-attachment service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::ad-attachment.ad-attachment');
