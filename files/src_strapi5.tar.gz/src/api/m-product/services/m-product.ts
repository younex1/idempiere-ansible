/**
 * m-product service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::m-product.m-product');
